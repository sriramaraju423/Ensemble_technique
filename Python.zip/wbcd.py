#!/usr/bin/env python
# coding: utf-8

# In[45]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
import numpy as np


# In[2]:


wbcd = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 20 - Ensemble\Dataset\wbcd.csv")
wbcd.head(10)


# In[7]:


wbcd.drop('id',inplace=True,axis=1)
wbcd


# #### EDA

# In[8]:


wbcd.isnull().sum()


# In[9]:


#Splitting data


# In[55]:


df_x = wbcd_no_outlier.iloc[:,1:]
df_y = wbcd_no_outlier.iloc[:,0]


# In[56]:


train_x,test_x,train_y,test_y = train_test_split(df_x,df_y,test_size=0.2,random_state=4)


# In[57]:


#building adaboost model


# In[58]:


ada = AdaBoostClassifier(DecisionTreeClassifier(),n_estimators=100,learning_rate=0.85)


# In[59]:


ada.fit(train_x,train_y)


# In[60]:


ada.score(train_x,train_y)


# In[61]:


ada.score(test_x,test_y)


# In[27]:


# n_estimators=100; train:1.0 test:0.9210526315789473
# n_estimators=200; train:1.0 test:0.9122807017543859
# n_estimators=200; train:1.0 test:0.9298245614035088; data = wbcd_no_outlier


# In[33]:


#Building Gradient boost model


# In[62]:


xgb = GradientBoostingClassifier(n_estimators=200,learning_rate=0.85)


# In[63]:


xgb.fit(train_x,train_y)


# In[64]:


xgb.score(train_x,train_y)


# In[65]:


xgb.score(test_x,test_y)


# In[38]:


# n_estimators=200; train:1.0; test:0.9210526315789473
# n_estimators=200; train:1.0; test:0.9473684210526315; data: wbcd_no_outlier; model: GradientBoostingClassifier


# In[39]:


#Still there is a slight overfitting model


# In[40]:


#Let me try and remove outliers and see if accuracy can be increased


# In[42]:


Q1 = wbcd.quantile(0.25)
Q3 = wbcd.quantile(0.75)
IQR = Q3 - Q1 
IQR


# In[43]:


col_continous = wbcd.columns[1:]
col_continous


# In[47]:


wbcd_no_outlier = pd.DataFrame(columns=wbcd.columns)
for i in col_continous:
    min_value = wbcd[i].min()
    max_value = wbcd[i].max()
    wbcd_no_outlier[i]=np.where(wbcd[i]<(Q1-1.5*IQR)[i],min_value,wbcd[i])
    wbcd_no_outlier[i]=np.where(wbcd[i]>(Q3+1.5*IQR)[i],max_value,wbcd[i])
wbcd_no_outlier['diagnosis'] = wbcd['diagnosis']
wbcd_no_outlier


# In[ ]:


# Let's try building model with 'wbcd_no_outlier' data


# #### Conclusion: n_estimators=200; train:1.0; test:0.9473684210526315; data: wbcd_no_outlier; model: GradientBoostingClassifier. This is good to go model for this dataset
