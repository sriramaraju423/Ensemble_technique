#!/usr/bin/env python
# coding: utf-8

# In[65]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import MinMaxScaler
import numpy as np


# In[2]:


Diabetes_RF = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 20 - Ensemble\Dataset\Diabetes_RF.csv")
Diabetes_RF.head(10)


# In[4]:


Diabetes_RF.shape


# In[79]:


df_x = Diabetes_RF.iloc[:,:8]
df_y = Diabetes_RF.iloc[:,8]


# In[80]:


train_x,test_x,train_y,test_y = train_test_split(df_x,df_y,test_size=0.2,random_state=4)


# In[81]:


train_x = MinMaxScaler().fit_transform(train_x)
test_x = MinMaxScaler().fit_transform(test_x)


# In[7]:


# Let's build ada boost model and check accuracy


# In[82]:


ada = AdaBoostClassifier(DecisionTreeClassifier(max_depth=1),n_estimators=200,learning_rate=0.85)


# In[83]:


ada.fit(train_x,train_y)


# In[84]:


ada.score(train_x,train_y)


# In[85]:


ada.score(test_x,test_y)


# In[16]:


#Accuracy without 'DecisionTreeClassifier' in ada boost: Train: 0.8045602605863192; test: 0.7727272727272727
#Didn't change anything with 'DecisionTreeClassifier()' as parameter
#n_estimators=50; train: 0.8159609120521173; test: 0.7597402597402597
#n_estimators=200; train: 0.8648208469055375; test: 0.7857142857142857
#The best test accuracy that i could get in random forest is: n_estimators=50 -> Accuracy: 0.7597402597402597
# 'Diabetes_no_outlier' data. Accuracy: Train: 0.8501628664495114; test: 0.7402597402597403


# In[33]:


#Now let's try and build model with Gradient boosting


# In[74]:


xgb = GradientBoostingClassifier(n_estimators=200,learning_rate=0.85)


# In[75]:


xgb.fit(train_x,train_y)


# In[76]:


xgb.score(train_x,train_y)


# In[77]:


xgb.score(test_x,test_y)


# In[78]:


# Final accuracy with GradientBoostingClassifier is train: 1.0 test: 0.7337662337662337
#I fitted the data and tried to build model.(As per googling). Accuracy: train: 1.0 test: 0.7467532467532467
#Using DecisionTreeClassifier(max_depth=1) as parameter it's throwing error. Not sure why. Sir didn't cover Gradient boosting and googled examples didn't have this parameter.
# 'Diabetes_no_outlier' data. Accuracy: Train: 1.0; test: 0.7402597402597403


# In[59]:


#High overfitting problem


# In[60]:


# I will try and handle outliers and see if that can increase any accuracy


# In[62]:


Q1 = Diabetes_RF.quantile(0.25)
Q3 = Diabetes_RF.quantile(0.75)
IQR = Q3 - Q1 
IQR


# In[63]:


col_continous = Diabetes_RF.columns[1:8]
col_continous


# In[66]:


Diabetes_no_outlier = pd.DataFrame(columns=Diabetes_RF.columns)
for i in col_continous:
    min_value = Diabetes_RF[i].min()
    max_value = Diabetes_RF[i].max()
    Diabetes_no_outlier[i]=np.where(Diabetes_RF[i]<(Q1-1.5*IQR)[i],min_value,Diabetes_RF[i])
    Diabetes_no_outlier[i]=np.where(Diabetes_RF[i]>(Q3+1.5*IQR)[i],max_value,Diabetes_RF[i])
Diabetes_no_outlier[' Number of times pregnant'] = Diabetes_RF[' Number of times pregnant']
Diabetes_no_outlier[' Class variable'] = Diabetes_RF[' Class variable']
Diabetes_no_outlier


# In[67]:


#Now i will try and fit this data


# In[ ]:


#Even the data without outliers didn't solve the overfitting problem


# #### Conclusion: I did every other way possible to get an accurate model(You can find it out in respective comments). But still there seems to be overfitting problem. I presume two things as reason 1)Dataset might not be suiting this classification technique so may need to try all other classifcation techniques 2)If accuracy is not met with required classification, then we may need to try and do stacking esemeble of multiple techniques and try to build accurate model 3)We may need fairly large dataset for more accuracy

# ##### Queries: If there is any thing additional that you feel i could do please let me know
